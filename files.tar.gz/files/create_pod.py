#!/usr/bin/env python3
import argparse
import csv
import re
import subprocess
import time
import shlex
import sys
from typing import List, Dict

# -------- helpers --------
def run(cmd: List[str], stdin_text: str | None = None, check: bool = False) -> subprocess.CompletedProcess:
    print("$", " ".join(shlex.quote(c) for c in cmd))
    result = subprocess.run(
        cmd,
        input=stdin_text,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if check and result.returncode != 0:
        print(f"ERROR: Command failed with code {result.returncode}", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
    return result

def sanitize(name: str) -> str:
    """Turn a CSV column into a valid pod name (DNS-1123)."""
    s = re.sub(r'[^a-z0-9-]+', '-', name.strip().lower())
    s = re.sub(r'-+', '-', s).strip('-')
    if not s:
        s = "pod"
    if not s[0].isalpha():
        s = "p-" + s
    return s[:63]

def make_pod_yaml(pod: str, namespace: str, node: str, image: str) -> str:
    return f"""apiVersion: v1
kind: Pod
metadata:
  name: fake-{pod}
  namespace: {namespace}
  labels:
    app: {pod}
    managed-by: kwok-power-simulator
spec:
  nodeName: {node}
  containers:
    - name: pause
      image: {image}
  restartPolicy: Never
"""

def kubectl_cmd_list(kubectl_cmd: str) -> List[str]:
    return kubectl_cmd.strip().split()

def verify_kwok_node(kubectl: List[str], node: str) -> bool:
    """Check if KWOK node exists and is Ready."""
    p = run(kubectl + ["get", "node", node, "-o", "json"])
    if p.returncode != 0:
        print(f"ERROR: Node '{node}' not found!", file=sys.stderr)
        print(f"Create it with: kwokctl create cluster", file=sys.stderr)
        return False
    
    # Check if it's a KWOK node
    if "kwok.x-k8s.io/node" not in p.stdout:
        print(f"WARNING: Node '{node}' exists but may not be a KWOK fake node", file=sys.stderr)
    
    return True

def verify_kwok_stages(kubectl: List[str]) -> bool:
    """Check if KWOK Stage resources exist for pod lifecycle."""
    p = run(kubectl + ["get", "stages.kwok.x-k8s.io"])
    if p.returncode != 0:
        print("WARNING: No KWOK Stage resources found. Pods may not transition to Running state.", file=sys.stderr)
        print("Consider creating Stage resources for pod lifecycle management.", file=sys.stderr)
        return False
    return True

def create_or_apply_pod(kubectl: List[str], yaml_text: str, pod: str) -> bool:
    p = run(kubectl + ["apply", "-f", "-"], stdin_text=yaml_text)
    if p.returncode != 0:
        print(f"Failed to create pod {pod}:", file=sys.stderr)
        print(p.stderr, file=sys.stderr)
        return False
    return True

def annotate(kubectl: List[str], namespace: str, pod: str, key: str, value: str) -> bool:
    p = run(kubectl + [
        "annotate", "pod", f"fake-{pod}", f"{key}={value}", "--overwrite", "-n", namespace
    ])
    if p.returncode != 0:
        print(f"Failed to annotate pod {pod}:", file=sys.stderr)
        print(p.stderr, file=sys.stderr)
        return False
    return True

def get_pod_status(kubectl: List[str], namespace: str, pod: str) -> str:
    """Get current pod status."""
    p = run(kubectl + ["get", "pod", f"fake-{pod}", "-n", namespace, "-o", "jsonpath={.status.phase}"])
    if p.returncode == 0:
        return p.stdout.strip()
    return "Unknown"

# -------- main workflow --------
def main():
    ap = argparse.ArgumentParser(description="Create KWOK fake pods then annotate from CSV.")
    ap.add_argument("--csv", required=True, help="CSV with Time + columns-per-pod (Watts).")
    ap.add_argument("--namespace", default="default")
    ap.add_argument("--kwok-node", default="kwok-node-1", help="KWOK node to pin pods on.")
    ap.add_argument("--kubectl-cmd", default="k3s kubectl",
                    help='Command to call kubectl (e.g. "kubectl" or "k3s kubectl").')
    ap.add_argument("--pause-image", default="registry.k8s.io/pause:3.9")
    ap.add_argument("--mode", choices=["static","stream"], default="static",
                    help="static: create + static annotations; stream: also update power every row.")
    ap.add_argument("--step-sec", type=float, default=1.0, help="Seconds between CSV rows in stream mode.")
    ap.add_argument("--verify", action="store_true", help="Verify KWOK setup before proceeding.")
    args = ap.parse_args()

    K = kubectl_cmd_list(args.kubectl_cmd)

    # Verify KWOK setup if requested
    if args.verify:
        print("Verifying KWOK setup...")
        if not verify_kwok_node(K, args.kwok_node):
            sys.exit(1)
        verify_kwok_stages(K)

    # Read CSV header and rows
    with open(args.csv, newline="") as f:
        r = csv.DictReader(f)
        all_cols = r.fieldnames or []
        pod_cols = [c for c in all_cols[1:] if c and c != "Time" and not c.startswith("Unnamed")]
        rows = list(r)

    if not pod_cols:
        raise SystemExit("No pod columns found. CSV must have 'Time' and per-pod columns.")

    col_to_pod: Dict[str, str] = {c: sanitize(c) for c in pod_cols}

    # 1) Create pods pinned to the KWOK node
    print(f"\nCreating {len(col_to_pod)} pods on node {args.kwok_node} in ns {args.namespace} ...")
    success_count = 0
    for col, pod in col_to_pod.items():
        y = make_pod_yaml(pod, args.namespace, args.kwok_node, args.pause_image)
        if create_or_apply_pod(K, y, pod):
            success_count += 1
    
    print(f"Successfully created/updated {success_count}/{len(col_to_pod)} pods")
    
    # Wait a bit for pods to be scheduled
    print("\nWaiting 2 seconds for pods to be scheduled...")
    time.sleep(2)
    
    # Check pod statuses
    print("\nChecking pod statuses...")
    for col, pod in col_to_pod.items():
        status = get_pod_status(K, args.namespace, pod)
        print(f"  {pod}: {status}")

    # 2) Static annotations (one-time)
    print("\nAnnotating static mapping (power.series, power.source) ...")
    for col, pod in col_to_pod.items():
        annotate(K, args.namespace, pod, "power.series", col)
        annotate(K, args.namespace, pod, "power.source", "kepler_csv")
        annotate(K, args.namespace, pod, "metrics.power_name", "kwok.x-k8s.io/usage-power-watts")

    if args.mode == "static":
        print("\nDone (static mode).")
        print(f"\nTo watch annotations live, run:")
        print(f"  watch -n 1 'kubectl get pods -n {args.namespace} -o custom-columns=NAME:.metadata.name,POWER:.metadata.annotations.kwok\\\\.x-k8s\\\\.io/usage-power-watts'")
        return

    # 3) Stream current power as an annotation
    print("\nStreaming current power into annotations (kwok.x-k8s.io/usage-power-watts) ...")
    print("Ctrl+C to stop.\n")
    try:
        for idx, row in enumerate(rows):
            timestamp = row.get("Time", f"row-{idx}")
            print(f"Processing row {idx+1}/{len(rows)} (Time: {timestamp})...")
            
            for col, pod in col_to_pod.items():
                raw = row.get(col, "")
                if raw in ("", None):
                    continue
                try:
                    float(raw)
                    annotate(K, args.namespace, pod, "kwok.x-k8s.io/usage-power-watts", str(raw))
                except ValueError:
                    continue
            
            time.sleep(args.step_sec)
    except KeyboardInterrupt:
        print("\n\nStopped by user.")
    
    print("\nFinished streaming.")
    print(f"\nTo view final annotations, run:")
    print(f"  kubectl get pods -n {args.namespace} -o json | jq '.items[] | {{name: .metadata.name, power: .metadata.annotations[\"kwok.x-k8s.io/usage-power-watts\"]}}'")

if __name__ == "__main__":
    main()
