#!/usr/bin/env python3
"""
KWOK Annotation Metrics Exporter
Reads pod annotations and exposes them as Prometheus metrics
"""
import time
import subprocess
import json
import re
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
import argparse

class MetricsHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/metrics':
            try:
                metrics = self.server.get_metrics()
                self.send_response(200)
                self.send_header('Content-Type', 'text/plain; version=0.0.4')
                self.end_headers()
                self.wfile.write(metrics.encode('utf-8'))
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(f"Error: {str(e)}\n".encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()
    
    def log_message(self, format, *args):
        # Suppress default logging
        pass

class MetricsServer(HTTPServer):
    def __init__(self, server_address, kubectl_cmd, namespace, annotation_prefix):
        super().__init__(server_address, MetricsHandler)
        self.kubectl_cmd = kubectl_cmd
        self.namespace = namespace
        self.annotation_prefix = annotation_prefix
        self.last_metrics = ""
        self.last_update = 0
        self.cache_ttl = 5  # Cache metrics for 5 seconds
    
    def get_metrics(self):
        now = time.time()
        if now - self.last_update < self.cache_ttl:
            return self.last_metrics
        
        try:
            # Get pods with annotations
            cmd = self.kubectl_cmd + ['get', 'pods', '-n', self.namespace, '-o', 'json']
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode != 0:
                return f"# Error fetching pods: {result.stderr}\n"
            
            data = json.loads(result.stdout)
            metrics_lines = []
            
            # Header
            metrics_lines.append("# HELP kwok_pod_annotation Pod annotations from KWOK simulator")
            metrics_lines.append("# TYPE kwok_pod_annotation gauge")
            
            # Process each pod
            for pod in data.get('items', []):
                pod_name = pod['metadata']['name']
                namespace = pod['metadata']['namespace']
                node = pod['spec'].get('nodeName', 'unknown')
                annotations = pod['metadata'].get('annotations', {})
                
                # Extract annotations matching our prefix
                for key, value in annotations.items():
                    if key.startswith(self.annotation_prefix):
                        # Extract metric name from annotation key
                        metric_suffix = key.replace(self.annotation_prefix, '').replace('/', '_').replace('-', '_').replace('.', '_')
                        
                        # Try to parse value as float
                        try:
                            metric_value = float(value)
                        except ValueError:
                            # If not a number, skip it
                            continue
                        
                        # Create metric name
                        metric_name = f"kwok_pod_annotation_{metric_suffix}"
                        
                        # Create labels
                        labels = f'pod="{pod_name}",namespace="{namespace}",node="{node}",annotation="{key}"'
                        
                        metrics_lines.append(f"{metric_name}{{{labels}}} {metric_value}")
            
            # Add metadata about the exporter
            metrics_lines.append("")
            metrics_lines.append("# HELP kwok_exporter_last_scrape_timestamp_seconds Timestamp of last scrape")
            metrics_lines.append("# TYPE kwok_exporter_last_scrape_timestamp_seconds gauge")
            metrics_lines.append(f"kwok_exporter_last_scrape_timestamp_seconds {now}")
            
            self.last_metrics = "\n".join(metrics_lines) + "\n"
            self.last_update = now
            
            return self.last_metrics
            
        except Exception as e:
            return f"# Error generating metrics: {str(e)}\n"

def main():
    parser = argparse.ArgumentParser(
        description='Export KWOK pod annotations as Prometheus metrics'
    )
    parser.add_argument('--port', type=int, default=9102,
                        help='Port to expose metrics on (default: 9102)')
    parser.add_argument('--namespace', default='default',
                        help='Kubernetes namespace to monitor (default: default)')
    parser.add_argument('--annotation-prefix', default='kwok.x-k8s.io/',
                        help='Annotation prefix to export (default: kwok.x-k8s.io/)')
    parser.add_argument('--kubectl-cmd', default='k3s kubectl',
                        help='kubectl command to use (default: "k3s kubectl")')
    
    args = parser.parse_args()
    kubectl = args.kubectl_cmd.strip().split()
    
    print(f"Starting KWOK Annotation Metrics Exporter")
    print(f"  Port: {args.port}")
    print(f"  Namespace: {args.namespace}")
    print(f"  Annotation prefix: {args.annotation_prefix}")
    print(f"  Kubectl command: {' '.join(kubectl)}")
    print(f"\nMetrics available at: http://localhost:{args.port}/metrics")
    print("Press Ctrl+C to stop\n")
    
    server = MetricsServer(
        ('0.0.0.0', args.port),
        kubectl,
        args.namespace,
        args.annotation_prefix
    )
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down exporter...")
        server.shutdown()

if __name__ == '__main__':
    main()
